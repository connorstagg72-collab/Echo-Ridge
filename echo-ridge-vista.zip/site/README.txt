ECHO RIDGE VISTA — website
==========================

WHAT'S HERE
  index.html    the whole site (125 KB, readable source)
  photos/       22 images

HOW TO VIEW IT
  Double-click index.html. Keep it in the same folder as photos/
  or the images won't load.

HOW TO PUT IT ONLINE
  Drag this whole folder onto netlify.com/drop — that's it, it's live.
  Same folder works for Vercel, Cloudflare Pages, or any web host.

CHANGING THINGS
  Open index.html in any text editor. Near the bottom of the file,
  in the <script> section, you'll find plain lists you can edit:

    IMG       which photo file each slot uses
    INSIDE    the 5 interior photos + captions
    RESORT    the 13 resort photos + captions
    BEDS      the sleeping arrangements grid
    FAQS      the questions and answers
    REVIEWS   the 19 guest reviews
    KEYWORDS  what guests mention most
    MAP_CATS  the map search categories
    GREETING  Mickell's two opening lines
    TICKER    the scrolling amenity strip

SWAPPING A PHOTO
  Drop your new image into photos/ and either give it the same
  filename as the old one, or update the name in the IMG list.

STILL TO CONNECT
  - Accounts:  signUp() / signIn() / signOutUser()  -> Supabase auth
  - Messages:  sendToBackend()                      -> Supabase insert
  Each is marked REPLACE ME in the code.
